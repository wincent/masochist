#!/bin/sh

# work around Tiger Launch Services issue
# see: http://wincent.com/a/support/bugs/show_bug.cgi?id=192
LSREGISTER="/System/Library/Frameworks/ApplicationServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister"

# bail if lsregister is not present and executable on system
if [ ! -x "${LSREGISTER}" ]; then
  echo lsregister not present and executable on this system > /dev/stderr
  exit 0
fi

if [ ${INSTALLATIONDOMAIN} = "Global" ]; then
  echo Running lsregister in the Global domain > /dev/stderr
  "${LSREGISTER}" -f "/Library/PreferencePanes/Synergy.prefPane/Contents/Resources/Synergy.app"
else
  echo Running lsregister in the User domain > /dev/stderr
  "${LSREGISTER}" -f "${HOME}/Library/PreferencePanes/Synergy.prefPane/Contents/Resources/Synergy.app"
fi

exit 0
