#!/bin/sh

# get previous Launch at login setting
LOGIN=`/usr/bin/defaults read org.wincent.Synergy "Launch at login" 2> /dev/null`

# proceed only if previous preference value exists
if [ $? -ne 0 ]; then
  exit 0
fi

# check Launch at login == YES
if [ ${LOGIN} -ne 1 ]; then
  exit 0
fi

# Using osascript and "System Events.app" doesn't work reliably under 10.3
# and the defaults command line tool can't insert/remove dictionaries from an
# array, so use home-baked solution (removes "Synergy.app" then re-adds it)

if [ -x "${SCRIPTDIRECTORY}/login-tool" ]; then
  echo Updating login items > /dev/stderr
  if [ ${INSTALLATIONDOMAIN} = "Global" ]; then
    "${SCRIPTDIRECTORY}/login-tool" \
      -r "Synergy.app" \
      -a "/Library/PreferencePanes/Synergy.prefPane/Contents/Resources/Synergy.app"
  else
    "${SCRIPTDIRECTORY}/login-tool" \
      -r "Synergy.app" \
      -a "~/Library/PreferencePanes/Synergy.prefPane/Contents/Resources/Synergy.app"
  fi
fi

exit 0
