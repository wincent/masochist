$Id: README.txt 14 2006-02-19 15:39:58Z wincent $

EXTRACTING THE DISTRIBUTION

The Omni Source License which applies to this software disallows the distribution of modified source code but allows the distribution of patches. As a result, the program source code (the file, "main.m") is not included with this distribution. Instead, a patch against the original source code is provided. To automatically extract and apply the patch:

1. Open the "wincent-strings-util.xcodeproj" bundle in Xcode.
2. Select and build the "extract-distribution" target.

USING THE WINCENT STRINGS UTILITY

All other documentation (including copyright and license information) for wincent-strings-util is included with this distribution in man page format. You can read it using the man(1) commandline tool. If the man page file (wincent-strings-util.1) is in your current working directory you can view it by typing in the terminal:

man ./wincent-strings-util.1

For more information on man, type "man man" in the terminal.