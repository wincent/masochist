// Copyright 2002 Omni Development, Inc.  All rights reserved.
//
// This software may only be used and reproduced according to the
// terms in the file OmniSourceLicense.html, which should be
// distributed with this project and can also be found at
// http://www.omnigroup.com/DeveloperResources/OmniSourceLicense.html.
//
// $Header: /Network/Source/CVS/Staff/len/stringsUtil/main.m,v 1.2 2002/03/26 04:27:43 len Exp $

#import <Foundation/Foundation.h>
#import <unistd.h>

@interface NSScanner (CharacterAdditions)
- (BOOL)peekCharacter:(unichar *)value;
- (BOOL)scanCharacter:(unichar *)value;
- (BOOL)scanComment:(NSString **)value;
- (BOOL)scanQuotedString:(NSString **)value;
- (NSString *)describeScanLocation;
@end

@implementation NSScanner (CharacterAdditions)
- (BOOL)peekCharacter:(unichar *)value;
{
    unsigned scanLocation;
    NSString *string;

    scanLocation = [self scanLocation];
    string = [self string];

    if ([string length] <= scanLocation+1)
        return NO;

    *value = [string characterAtIndex:scanLocation];
    return YES;
}

- (BOOL)scanCharacter:(unichar *)value;
{
    unsigned scanLocation;
    NSString *string;

    scanLocation = [self scanLocation];
    string = [self string];

    if ([string length] <= scanLocation+1)
        return NO;

    *value = [string characterAtIndex:scanLocation];
    [self setScanLocation:scanLocation+1];
    
    return YES;
}

- (BOOL)scanComment:(NSString **)value;
{
    if ([self scanString:@"//" intoString:NULL]) {
        [self scanUpToString:@"\n" intoString:value];
        [self scanString:@"\n" intoString:NULL];
        
        return YES;
    }
    
    if ([self scanString:@"/*" intoString:NULL]) {
        [self scanUpToString:@"*/" intoString:value];
        
        return [self scanString:@"*/" intoString:NULL];
    }

    return NO;
}

- (BOOL)scanQuotedString:(NSString **)value;
{
    NSString *tempString;
    NSMutableString *result;
    NSCharacterSet *specialCharacterSet;

    if (![self scanString:@"\"" intoString:&tempString])
        return NO;

    specialCharacterSet = [NSCharacterSet characterSetWithCharactersInString:@"\r\n\"\\"];
    result = [NSMutableString stringWithString:tempString];

    while (![self isAtEnd]) {
        NSString *tempString;
        unichar scanCharacters[2];

        if ([self scanUpToCharactersFromSet:specialCharacterSet intoString:&tempString])
            [result appendString:tempString];

        if (![self scanCharacter:&scanCharacters[0]])
            return NO;

        switch (scanCharacters[0]) {
            
            case '\"':
                [result appendString:@"\""];
                *value = [NSString stringWithString:result];
                return YES;
                
            case '\\':
                if (![self scanCharacter:&scanCharacters[1]])
                    return NO;

                [result appendString:[NSString stringWithCharacters:scanCharacters length:2]];
                break;
                
            default:
                return NO;
        }
    }
    return NO;
}

- (NSString *)describeScanLocation;
{
    unsigned originalScanLocation;
    NSCharacterSet *originalCharactersToBeSkipped;
    unsigned lineStartLocation;
    unsigned lineCount;
    NSString *scanLocationDescription;
    NSString *lastLine;
    
    originalScanLocation = [self scanLocation];
    originalCharactersToBeSkipped = [self charactersToBeSkipped];

    [self setScanLocation:0];
    [self setCharactersToBeSkipped:nil];
    
    lineStartLocation = 0;
    lineCount = 0;
    while (([self scanLocation]) <= originalScanLocation && ![self isAtEnd]) {
        lineStartLocation = [self scanLocation];
        if (![self scanUpToString:@"\n" intoString:&lastLine])
            lastLine = @"\n";
        if ([self scanString:@"\n" intoString:NULL])
            lineCount++;
    }

    scanLocationDescription = [NSString stringWithFormat:@"location %d -- line %d character %d\n%@", originalScanLocation, lineCount, originalScanLocation-lineStartLocation, lastLine];

    [self setScanLocation:originalScanLocation];
    [self setCharactersToBeSkipped:originalCharactersToBeSkipped];

    return scanLocationDescription;
}
@end

NSArray *parseStringsFile(NSString *string)
{
    NSScanner *stringScanner;
    NSCharacterSet *whitespaceCharacterSet;
    NSMutableArray *comments;
    NSMutableArray *entries;

    stringScanner = [NSScanner scannerWithString:string];
    [stringScanner setCharactersToBeSkipped:nil];
    [stringScanner setCaseSensitive:NO];

    whitespaceCharacterSet = [NSCharacterSet characterSetWithCharactersInString:@"\n\r\t "];
    comments = [NSMutableArray array];
    entries = [NSMutableArray array];
    
    while (![stringScanner isAtEnd]) {
        unichar peekCharacter;

        [stringScanner scanCharactersFromSet:whitespaceCharacterSet intoString:NULL];
        if (![stringScanner peekCharacter:&peekCharacter])
            break;
        
        if (peekCharacter == '/') {
            NSString *comment = nil;

            // look for comment
            if (![stringScanner scanComment:&comment])
                [NSException raise:NSGenericException format:@"Invalid comment at %@", [stringScanner describeScanLocation]];

            [comments addObject:comment];

            continue;
        }

        if (peekCharacter == '\"') {
            NSString *key;
            NSString *value;
            
            if (![stringScanner scanQuotedString:&key])
                [NSException raise:NSGenericException format:@"Invalid key at %@", [stringScanner describeScanLocation]];

            [stringScanner scanCharactersFromSet:whitespaceCharacterSet intoString:NULL];

            if (![stringScanner scanString:@"=" intoString:NULL])
                [NSException raise:NSGenericException format:@"Can't find = separating key and value at %@", [stringScanner describeScanLocation]];

            [stringScanner scanCharactersFromSet:whitespaceCharacterSet intoString:NULL];

            if (![stringScanner scanQuotedString:&value])
                [NSException raise:NSGenericException format:@"Invalid value at %@", [stringScanner describeScanLocation]];

            [stringScanner scanCharactersFromSet:whitespaceCharacterSet intoString:NULL];

            if (![stringScanner scanString:@";" intoString:NULL]) {
                NSLog(@"Missing ; at %@", [stringScanner describeScanLocation]);
                //[NSException raise:NSGenericException format:@"Missing ; at %@", [stringScanner describeScanLocation]];
            }

            [entries addObject:[NSDictionary dictionaryWithObjectsAndKeys:key, @"key", value, @"value", [NSArray arrayWithArray:comments], @"comments", nil]];
            [comments removeAllObjects];
        }
    }

    return entries;
}

NSArray *mergeStrings(NSArray *baseEntries, NSArray *mergeEntries)
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSMutableArray *resultArray;
    NSMutableDictionary *mergeDictionary;
    unsigned mergeEntryIndex, mergeEntryCount;
    unsigned baseEntryIndex, baseEntryCount;
    
    baseEntryCount = [baseEntries count];
    resultArray = [NSMutableArray arrayWithCapacity:baseEntryCount];

    mergeEntryCount = [mergeEntries count];
    mergeDictionary = [NSMutableDictionary dictionary];

    for (mergeEntryIndex = 0; mergeEntryIndex < mergeEntryCount; mergeEntryIndex++) {
        NSDictionary *mergeEntry;

        mergeEntry = [mergeEntries objectAtIndex:mergeEntryIndex];
        [mergeDictionary setObject:[mergeEntry objectForKey:@"value"] forKey:[[mergeEntry objectForKey:@"key"] propertyList]];
    }

    for (baseEntryIndex = 0; baseEntryIndex < baseEntryCount; baseEntryIndex++) {
        NSMutableDictionary *resultEntry;
        NSDictionary *mergeValue;

        resultEntry = [NSMutableDictionary dictionaryWithDictionary:[baseEntries objectAtIndex:baseEntryIndex]];
        mergeValue = [mergeDictionary objectForKey:[[resultEntry objectForKey:@"key"] propertyList]];
        
        if (mergeValue != nil)
            [resultEntry setObject:mergeValue forKey:@"value"];
        else
            NSLog(@"*** merge missing key '%s'", [[resultEntry objectForKey:@"key"] UTF8String]);
        
        [resultArray addObject:[NSDictionary dictionaryWithDictionary:resultEntry]];
    }
    
    resultArray = [[NSArray alloc] initWithArray:resultArray];
    [pool release];
    
    return [resultArray autorelease];
}

NSString *stringsFileFromEntries(NSArray *entries)
{
    NSMutableString *resultString;
    unsigned entryIndex, entryCount;

    resultString = [NSMutableString string];
    entryCount = [entries count];
    
    for (entryIndex = 0; entryIndex < entryCount; entryIndex++) {
        NSDictionary *entry;
        NSArray *comments;
        unsigned commentIndex, commentCount;

        entry = [entries objectAtIndex:entryIndex];
        comments = [entry objectForKey:@"comments"];
        commentCount = [comments count];
        
        for (commentIndex = 0; commentIndex < commentCount; commentIndex++) {
            [resultString appendString:@"/" @"*"];
            [resultString appendString:[comments objectAtIndex:commentIndex]];
            [resultString appendString:@"*" @"/" @"\n"];
        }
        [resultString appendString:[entry objectForKey:@"key"]];
        [resultString appendString:@" = "];
        [resultString appendString:[entry objectForKey:@"value"]];
        [resultString appendString:@";\n\n"];
    }
    return [NSString stringWithString:resultString];
}

NSMutableData *convertToNonLossyASCII(NSString *string)
{
    unsigned stringLength;
    NSMutableData *data;
    unsigned stringIndex;

    stringLength = [string length];
    data = [NSMutableData dataWithCapacity:stringLength*2];

    for (stringIndex = 0; stringIndex < stringLength; stringIndex++) {
        unichar unicodecharacter;

        unicodecharacter = [string characterAtIndex:stringIndex];
        switch (unicodecharacter) {
            case '\a': [data appendBytes:"\\a" length:2]; break;
            case '\b': [data appendBytes:"\\b" length:2]; break;
            case '\f': [data appendBytes:"\\f" length:2]; break;
            case '\n': [data appendBytes:"\\n" length:2]; break;
            case '\r': [data appendBytes:"\\r" length:2]; break;
            case '\t': [data appendBytes:"\\t" length:2]; break;
            case '\v': [data appendBytes:"\\v" length:2]; break;
            case '\"': [data appendBytes:"\\" "\"" length:2]; break;
            case '\\': [data appendBytes:"\\\\" length:2]; break;
            case '\0': [data appendBytes:"\\0" length:2]; break;
            default:
                if (unicodecharacter < 128) {
                    char character;

                    character = (char)unicodecharacter;
                    [data appendBytes:&character length:1];
                } else {
                    char bytes[7];

                    sprintf(bytes, "\\U%04hx", unicodecharacter);
                    [data appendBytes:bytes length:6];
                }
                break;
        }
    }
    return data;
}

int main (int argc, const char * argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    NSString *basePath;
    NSString *mergePath;
    NSString *outputPath;

    NSString *baseStringsFile;
    NSString *mergeStringsFile;

    NSArray *baseEntries;
    NSArray *mergeEntries;

    NSString *outputString;
    NSData *outputData;
    
    basePath = [[NSUserDefaults standardUserDefaults] stringForKey:@"base"];
    if (basePath == nil) {
        fprintf(stderr, "Usage: stringsUtil -base <file> [-merge <file>] [-output <file>]\n");
        exit(1);
        return 1;
    }

    baseStringsFile = [NSString stringWithContentsOfFile:basePath];
    baseEntries = parseStringsFile(baseStringsFile);
    //fprintf(stderr, "baseEntries = %s\n", [[baseEntries description] UTF8String]);

    mergePath = [[NSUserDefaults standardUserDefaults] stringForKey:@"merge"];
    if (mergePath != nil) {
        mergeStringsFile = [NSString stringWithContentsOfFile:mergePath];
        mergeEntries = parseStringsFile(mergeStringsFile);
        //fprintf(stderr, "mergeEntries = %s\n", [[mergeEntries description] UTF8String]);

        baseEntries = mergeStrings(baseEntries, mergeEntries);
        //fprintf(stderr, "resultEntries = %s\n", [[baseEntries description] UTF8String]);
    }

    outputString = stringsFileFromEntries(baseEntries);
    outputData = [outputString dataUsingEncoding:NSASCIIStringEncoding];

    if (outputData == nil)
        outputData = [outputString dataUsingEncoding:NSUnicodeStringEncoding];

    outputPath = [[NSUserDefaults standardUserDefaults] stringForKey:@"output"];

    if (outputPath != nil) {
        [outputData writeToFile:outputPath atomically:NO];
    } else {
        write(STDOUT_FILENO, [outputData bytes], [outputData length]);
    }
    [pool release];
    return 0;
}
