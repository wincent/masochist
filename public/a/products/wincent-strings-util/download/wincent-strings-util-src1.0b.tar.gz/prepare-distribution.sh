#!/bin/sh
#
#  prepare-distribution.sh
#  wincent-strings-util
#
#  Created by Wincent Colaiuta on Sat Feb 18 2006.
#  Copyright 2006 Wincent Colaiuta. All rights reserved.
#  $Id: prepare-distribution.sh 24 2006-02-19 19:01:01Z wincent $
#

# Omni disallows modified source distribution but patches are allowed...

set -e
echo "Preparing staging directory"
mkdir -p "${DERIVED_FILE_DIR}"
STAGING_DIR="${DERIVED_FILE_DIR}/wincent-strings-util-distribution"
/bin/rm -rfv "${STAGING_DIR}"

echo "Exporting a pristine copy of current source"
/usr/local/bin/svn export --non-interactive \
                   http://localhost:8080/svnrep/omni-strings-util/trunk \
                   "${STAGING_DIR}"

echo "Extracting original Omni source"
cd "${STAGING_DIR}"
/usr/bin/tar xzfv stringsUtil.tar.gz

echo "Performing diff"
# diff will always return an exit code of 1 here (files different), hence the ||
/usr/bin/diff -u stringsUtil/main.m main.m > wincent.diff || cd .

echo "Deleting modified source files"
/bin/rm -fv main.m

echo "Moving original Omni source files into main directory"
/bin/mv -fv stringsUtil/main.m .

echo "Deleting extracted Omni source folder"
/bin/rm -rfv stringsUtil

echo "Preparing archive of distribution"
/usr/bin/tar czvf ../wincent-strings-util.tar.gz .

echo "Moving archive into built products directory"
/bin/mv -fv ../wincent-strings-util.tar.gz "${BUILT_PRODUCTS_DIR}/"

echo "Done"
exit 0