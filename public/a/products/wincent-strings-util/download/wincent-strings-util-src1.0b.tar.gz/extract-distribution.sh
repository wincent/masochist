#!/bin/sh
#
#  extract-distribution.sh
#  wincent-strings-util
#
#  Created by Wincent Colaiuta on Sat Feb 18 2006.
#  Copyright 2006 Wincent Colaiuta. All rights reserved.
#  $Id: extract-distribution.sh 27 2006-02-19 19:12:11Z wincent $
#

# Omni disallows modified source distribution but patches are allowed...

cd "${SOURCE_ROOT}"
if [ ! -f wincent.diff ]; then
  echo "Distribution already extracted: exiting"
  exit 0
fi

set -e
echo "Extracting original Omni source"
/usr/bin/tar xzvf stringsUtil.tar.gz

echo "Applying patch"
/usr/bin/patch <wincent.diff

echo "Deleting extracted Omni source folder"
/bin/rm -rfv stringsUtil

echo "Renaming patch file"
/bin/mv -fv wincent.diff wincent.diff.applied

echo "Done"
exit 0