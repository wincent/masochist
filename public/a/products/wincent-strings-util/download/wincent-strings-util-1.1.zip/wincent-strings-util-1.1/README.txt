$Id: README.txt 37 2006-08-17 13:25:39Z wincent $

USING THE WINCENT STRINGS UTILITY

All other documentation (including copyright and license information) for wincent-strings-util is included with this distribution in man page format. You can read it using the man(1) commandline tool. If the man page file (wincent-strings-util.1) is in your current working directory you can view it by typing in the terminal:

man ./wincent-strings-util.1

For more information on man, type "man man" in the terminal.