USING THE WINCENT STRINGS UTILITY

All other documentation (including copyright and license information) for wincent-strings-util is included with this distribution in man page format. You can read it using the man(1) commandline tool. If the man page file (wincent-strings-util.1) is in your current working directory you can view it by typing in the terminal:

man ./wincent-strings-util.1

For more information on man, type "man man" in the terminal.


LICENSE NOTES

Wincent Strings Utility is copyright 2005-2008 Wincent Colaiuta. It is based on software developed by Omni Development, copyright 2002 Omni Development, Inc. This derivative work is made available according to the terms of the GNU General Public License (see file LICENSE.txt) with the permission of Omni Development.
