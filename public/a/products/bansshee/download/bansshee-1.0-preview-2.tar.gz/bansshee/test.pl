#!/usr/bin/perl
use strict;
use warnings;
use threads;
use threads::shared;
use Sys::Syslog qw(:DEFAULT setlogsock);
use sigtrap qw(die untrapped normal-signals); # ensure that END block gets run (to clean up iptables)
use Proc::Daemon;
use File::Tail;

our $logpath                  = '/var/log/nigger';  # logfile to watch

print "prestart\n";

die unless my $file = File::Tail->new(name=>$logpath, ignore_nonexistant=>1);

print "start\n";
while (defined(my $line=$file->read))
{
  print "woot\n";
}

print "nope\n";
exit 0;

END
{
print "end\n";
}
