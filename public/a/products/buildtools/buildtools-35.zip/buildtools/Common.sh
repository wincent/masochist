#!/bin/bash
#
# Common.sh
# buildtools
#
# Created by Wincent Colaiuta on 06/12/04.
#
# Copyright 2004-2006 Wincent Colaiuta.
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# in the accompanying file, "LICENSE.txt", for more details.
#
# $Id: Common.sh 27 2006-09-06 09:54:16Z wincent $

#
# Functions
#

warn()
{
  builtin echo ":: warning: $1"
}

err()
{
  builtin echo ":: error: $1"
}

