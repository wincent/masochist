#!/bin/bash
#
# RunDoxygen.sh
# buildtools
#
# Created by Wincent Colaiuta on 06/12/04.
#
# Copyright 2004-2006 Wincent Colaiuta.
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# in the accompanying file, "LICENSE.txt", for more details.
#
# $Id: RunDoxygen.sh 19 2006-06-11 17:21:47Z wincent $

#
# Defaults
#
DOXYFILE="${SOURCE_ROOT}/Doxyfile"
#DOXYGEN="/usr/local/bin/doxygen"
DOXYGEN="/Applications/Doxygen.app/Contents/Resources/doxygen"

#
# Functions
#
printusage()
{
  builtin echo 'Usage: $0 [Doxyfile]'
  builtin echo 'If "Doxyfile" is omitted "${SOURCE_ROOT}/Doxyfile" is assumed' 
}

#
# Main
#

set -e

# process arguments
if [ $# -eq 1 ]; then
  DOXYFILE="$1"
elif [ $# -gt 1 ]; then
  printusage
  exit 1
fi

# issue error message if Doxygen not installed
if [ ! -f "${DOXYGEN}" ]; then
  builtin echo "error: ${DOXYGEN} not found"
  exit 1
fi

builtin echo "Running Doxygen:"
"${DOXYGEN}" "${SOURCE_ROOT}/Doxyfile"
builtin echo "RunDoxygen.sh: Done"

